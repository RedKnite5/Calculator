# ReCalc
This is a graphing calculator written in python.

prerequisites:

To run this program you will need python 3.6, Sympy and tkinter.
I have tested it on Windows 10 and Fedora 26-27.

Installation:

Once you have installed the above get the files on github.

